import React, { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import Reveal from '../components/Reveal';
import './Home.css';
import './Apps.css';

const businessApps = [
  {
    name: 'TechnoPOS',
    color: '#7c3aed',
    url: 'https://app.technovia.com.au',
    tagline: 'Retail & business management platform',
    features: [
      'Manage inventory and stock levels',
      'Track sales, orders, and transactions',
    ],
  },
  {
    name: 'ChairTime',
    color: '#0284c7',
    url: 'https://booking.technovia.com.au',
    tagline: 'Smart booking & appointment management',
    features: [
      'Online appointment booking 24/7',
      'Manage staff schedules & availability',
    ],
  },
  {
    name: 'InvoiceGen',
    color: '#059669',
    url: 'https://invoice.technovia.com.au',
    tagline: 'Fast, professional invoicing',
    features: [
      'Create and send professional invoices',
      'Track invoice status and records',
    ],
  },
  {
    name: 'WFHly',
    color: '#7c3aed',
    url: 'https://wfh.technovia.com.au',
    tagline: 'Work-from-home tracking & expenses',
    features: [
      'Log work-from-home hours automatically',
      'Track home-office expenses & claims',
    ],
  },
];

const marqueeItems = [
  'Network Security', 'Cybersecurity', 'Cloud Infrastructure', 'AI Integration',
  'TechnoPOS', 'React', 'Python', 'Open to Work',
];

const skills = [
  { category: 'Security', items: ['Network Security', 'Threat Analysis', 'Encryption', 'Cybersecurity Principles'] },
  { category: 'Cloud & Infra', items: ['Microsoft Azure', 'AWS', 'VMware', 'VirtualBox', 'Docker', 'Kubernetes'] },
  { category: 'Networking', items: ['TCP/IP', 'DNS', 'VPN', 'VLANs', 'Firewalls', 'Active Directory'] },
  { category: 'Dev & AI', items: ['Python', 'Node.js', 'React', 'AI Integration', 'OpenCV', 'Dialogflow'] },
];

export default function Home() {
  const heroRef = useRef(null);

  useEffect(() => {
    const el = heroRef.current;
    if (!el) return;
    el.classList.add('hero-in');
  }, []);

  return (
    <div className="home page">
      {/* HERO */}
      <section className="hero" ref={heroRef}>
        <div className="hero-photo" aria-hidden="true">
          <img
            src={process.env.PUBLIC_URL + '/krishan.jpg'}
            alt=""
            onError={e => { e.target.style.display = 'none'; }}
          />
        </div>

        <div className="container">
          <div className="hero-grid">
            <div className="hero-text">
              <p className="hero-greeting">
                <span className="mono-label">$ whoami</span>
              </p>
              <h1 className="hero-name">
                <span className="hero-name-line"><span>Krishan</span></span>
                <span className="hero-name-line"><span className="name-accent">Himesh</span></span>
              </h1>
              <div className="status-badge status-badge-inline">
                <span className="status-dot" />
                Open to opportunities
              </div>
              <p className="hero-role">
                Network &amp; Cybersecurity Graduate
              </p>
              <p className="hero-bio">
                Passionate about building secure, scalable systems. Specialising in
                network engineering, cloud infrastructure, and AI-integrated solutions.
                Based in Australia 🇦🇺
              </p>
              <div className="hero-cta">
                <Link to="/projects" className="btn btn-primary">View Projects</Link>
                <a
                    href="https://docs.google.com/gview?embedded=1&url=https://raw.githubusercontent.com/KrishanHimesh/krishanhimesh.github.io/main/files/KrishanHimeshAbeyrathne.pdf"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn btn-outline"
                >
                  Resume ↗
                </a>
              </div>

              <div className="hero-socials">
                <a href="https://github.com/KrishanHimesh" target="_blank" rel="noopener noreferrer" className="social-link">
                  <GithubIcon /> GitHub
                </a>
                <a href="https://www.linkedin.com/in/krishan-himesh-723a42a7" target="_blank" rel="noopener noreferrer" className="social-link">
                  <LinkedinIcon /> LinkedIn
                </a>
                <a href="mailto:krishanhimesh@gmail.com" className="social-link">
                  <EmailIcon /> Email
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* MARQUEE STRIP */}
      <div className="marquee">
        <div className="marquee-track">
          {[...marqueeItems, ...marqueeItems].map((item, i) => (
            <span className="marquee-item" key={i}>
              {item} <span className="dot">●</span>
            </span>
          ))}
        </div>
      </div>

      {/* ABOUT */}
      <section className="about-section">
        <div className="container">
          <Reveal><p className="section-label">// about me</p></Reveal>
          <Reveal delay={1}><h2 className="section-title">Who I Am</h2></Reveal>
          <div className="about-grid">
            <Reveal as="div" className="about-text">
              <p>
                I am a recent graduate in Network and Cybersecurity with a strong foundation
                in IT principles, infrastructure design, and emerging technologies.
                My academic and project experience spans designing enterprise-grade networks,
                building cloud-connected IoT systems, and developing AI-powered applications.
              </p>
              <p>
                Beyond cybersecurity, I enjoy building software tools — including{' '}
                <Link to="/apps" style={{ color: 'var(--accent)' }}>TechnoPOS</Link>, a live
                POS &amp; inventory app I built and run for a small bookshop. I thrive at the
                intersection of security, cloud, and intelligent systems.
              </p>
              <p>
                I am eager to contribute to an entry-level role in network engineering or
                cybersecurity where I can grow, collaborate, and make a real impact.
              </p>
            </Reveal>
            <Reveal as="div" delay={2} className="about-highlights">
              {[
                { label: 'Degree', value: 'Network & Cybersecurity' },
                { label: 'Location', value: 'Australia' },
                { label: 'Focus', value: 'Network Engineering & Security' },
                { label: 'Interests', value: 'AI, Blockchain, Cloud' },
                { label: 'Status', value: 'Open to Work' },
              ].map(({ label, value }) => (
                <div className="highlight-item" key={label}>
                  <span className="highlight-label">{label}</span>
                  <span className="highlight-value">{value}</span>
                </div>
              ))}
            </Reveal>
          </div>
        </div>
      </section>

      {/* SKILLS */}
      <section className="skills-section">
        <div className="container">
          <Reveal><p className="section-label">// skills</p></Reveal>
          <Reveal delay={1}><h2 className="section-title">Technical Stack</h2></Reveal>
          <div className="skills-grid">
            {skills.map(({ category, items }, i) => (
              <Reveal as="div" delay={Math.min(i + 1, 4)} className="skill-card" key={category}>
                <h3 className="skill-category">{category}</h3>
                <ul className="skill-list">
                  {items.map(item => (
                    <li key={item} className="skill-item">
                      <span className="skill-dot" />
                      {item}
                    </li>
                  ))}
                </ul>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* APPS TEASER */}
      <section className="apps-teaser">
        <div className="container">
          <Reveal as="div" className="teaser-card">
            <div className="teaser-content">
              <p className="app-status-badge live" style={{ marginBottom: 18 }}>
                <span className="status-dot live-dot" />
                Live App — Ready to Use
              </p>
              <h2 className="teaser-title">TechnoPOS — POS &amp; Inventory App</h2>
              <p className="teaser-desc">
                A full inventory management and point-of-sale system I built and run for my
                small bookshop — Unity Book Shop. Track stock, ring up sales, and generate
                reports, all from one place, running right here on this site.
              </p>
              <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
                <Link to="/apps/bookshelf" className="btn btn-primary">🚀 Launch TechnoPOS</Link>
                <Link to="/apps" className="btn btn-outline">See All My Apps →</Link>
              </div>
            </div>
            <div className="teaser-graphic">
              <div className="book-stack">
                {['#ccff00', '#38bdf8', '#818cf8', '#34d399', '#ff6b6b'].map((c, i) => (
                  <div key={i} className="book-spine" style={{ background: c, animationDelay: `${i * 0.15}s` }} />
                ))}
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* MY APPS — DIRECT LINKS */}
      <section className="ext-apps-section">
        <div className="container">
          <Reveal><p className="section-label">// my apps</p></Reveal>
          <Reveal delay={1}><h2 className="section-title">Built for Technovia</h2></Reveal>
          <Reveal delay={2} as="p" className="apps-intro" style={{ marginBottom: 40 }}>
            Software I've built and shipped for my business, Technovia — live and in daily use.
            Jump straight in below.
          </Reveal>

          <div className="ext-apps-grid">
            {businessApps.map(({ name, color, url, tagline, features }, i) => (
              <Reveal as="div" delay={Math.min(i + 1, 4)} className="ext-app-card" key={name}>
                <h3 className="ext-app-title" style={{ color }}>{name}</h3>
                <p className="ext-app-tagline">{tagline}</p>
                <ul className="ext-app-features">
                  {features.map(f => (
                    <li key={f}>
                      <span className="ext-app-dot" style={{ background: color }} />
                      {f}
                    </li>
                  ))}
                </ul>
                <a
                  href={url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="ext-app-btn"
                  style={{ background: color }}
                >
                  Open {name} →
                </a>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

function GithubIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
      <path d="M12 0C5.37 0 0 5.37 0 12c0 5.3 3.44 9.8 8.2 11.38.6.11.82-.26.82-.58 0-.28-.01-1.02-.01-2-3.34.72-4.04-1.61-4.04-1.61-.54-1.38-1.33-1.75-1.33-1.75-1.09-.74.08-.73.08-.73 1.2.09 1.84 1.24 1.84 1.24 1.07 1.83 2.8 1.3 3.49 1 .1-.78.42-1.3.76-1.6-2.67-.3-5.47-1.33-5.47-5.93 0-1.31.47-2.38 1.24-3.22-.14-.3-.54-1.52.1-3.18 0 0 1.01-.32 3.3 1.23a11.5 11.5 0 0 1 3-.4c1.02 0 2.04.13 3 .4 2.28-1.55 3.29-1.23 3.29-1.23.64 1.66.24 2.88.12 3.18.77.84 1.23 1.91 1.23 3.22 0 4.61-2.81 5.63-5.48 5.92.43.37.81 1.1.81 2.22 0 1.6-.01 2.9-.01 3.29 0 .32.21.7.82.58C20.57 21.8 24 17.3 24 12c0-6.63-5.37-12-12-12z"/>
    </svg>
  );
}

function LinkedinIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
      <path d="M20.45 20.45h-3.55v-5.57c0-1.33-.03-3.04-1.85-3.04-1.85 0-2.14 1.45-2.14 2.94v5.67H9.36V9h3.41v1.56h.05c.47-.9 1.63-1.85 3.36-1.85 3.6 0 4.26 2.37 4.26 5.45v6.29zM5.34 7.43a2.06 2.06 0 1 1 0-4.12 2.06 2.06 0 0 1 0 4.12zM7.12 20.45H3.56V9h3.56v11.45zM22.22 0H1.77C.79 0 0 .77 0 1.72v20.56C0 23.23.79 24 1.77 24h20.45c.98 0 1.78-.77 1.78-1.72V1.72C24 .77 23.2 0 22.22 0z"/>
    </svg>
  );
}

function EmailIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="4" width="20" height="16" rx="2"/>
      <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>
    </svg>
  );
}
